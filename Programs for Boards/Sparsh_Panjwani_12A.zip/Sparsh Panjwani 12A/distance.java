class D2point
{
double x, y;
D2point(double nx, double ny)
{
x=nx;
y=ny;
}
double distance2d(D2point b)
{
b.x=

}
}
class D3point extends D2point
{
double z;
D3point(double nx, double ny, double nz)
{
z=nz;
}
double distance3d(D3point h)
{
h.z=
}
}

class distance
{
public static void main(String ar[])
{
Scanner sc=new Scanner(System.in);
D2 D2point=new D2point(x
