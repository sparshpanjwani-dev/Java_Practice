import java.io.*;
class Array1D
{
private int Arr[], N;
public static void main(String ar[])throws Exception
{
public int Array1D(int n)
{
n=Integer.parseInt(ob.readLine());
Arr=new Arr[n];
}
public void read()
{
System.out.println("Enter N");
N=Integer.parseInt(ob.readLine());
System.out.println("Enter numbers for the array");
for(int z=0;z<n;z++)
Arr[z]=Integer.parseInt(ob.readLine());
}
public void sort()
{
int m=0, p=0;
for(int i=0;i<i++)
{
m=a[i];
p=i-1;
while(p>0&&m<a[p])
{
Arr[p+1]=Arr[p];
p--;
}
Arr[p+1]=m;
}
}
public int Search()
{
for(int i=0;i<n-1;i++)
{
if(Arr[i]+Arr[i+1]==N)
System.out.println(Arr[i]+Arr[i+1])l;
}
return 0;
}
public void