class test
{
public static void main(String ar[])
{
int n=016;
System.out.print(n);
}
}