class ascii
{
public static void main(String ar[])throws Exception
{
for(int i=0;i<1000;i++)
System.out.println(i+"\t\t\t"+(char)(i));
}
}